function setup() {
  createCanvas(500, 1000);
}

function draw() {
  background(220);
  ellipse(20,20,20,20)
  
  
}